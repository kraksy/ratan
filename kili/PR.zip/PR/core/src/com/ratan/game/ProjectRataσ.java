package com.ratan.game;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class ProjectRataň extends ApplicationAdapter {
	 private Texture ratImage;
	  private OrthographicCamera camera;
	   private SpriteBatch batch;
	   private Rectangle rat;
	 
	 
	 @Override
	public void create () {
		 ratImage = new Texture(Gdx.files.internal("rat.jpg"));
		  camera = new OrthographicCamera();
		   camera.setToOrtho(false, 800, 480);
		   
		   batch = new SpriteBatch();
		   
		   rat = new Rectangle();
		   rat.x = 800 / 2 - 64 / 2;
		   rat.y = 20;
		   rat.width = 64;
		   rat.height = 64;
	 }
	
	 

	@Override
	public void render () {
		ScreenUtils.clear(0, 0, 0.2f, 1);
		 camera.update();
		 batch.setProjectionMatrix(camera.combined);
		   batch.begin();
		   batch.draw(ratImage, rat.x, rat.y);
		   batch.end();
		   if(Gdx.input.isKeyPressed(Input.Keys.A)) rat.x -= 200 * Gdx.graphics.getDeltaTime();
		   if(Gdx.input.isKeyPressed(Input.Keys.D)) rat.x += 200 * Gdx.graphics.getDeltaTime();
		   if(Gdx.input.isKeyPressed(Input.Keys.W)) rat.y += 200 * Gdx.graphics.getDeltaTime();
		   if(Gdx.input.isKeyPressed(Input.Keys.S)) rat.y -= 200 * Gdx.graphics.getDeltaTime();

	}
	@Override
	public void dispose () {
		batch.dispose();
		ratImage.dispose();
	}
}
